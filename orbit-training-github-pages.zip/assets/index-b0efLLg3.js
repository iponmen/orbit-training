import{t as e}from"./dev-panel-CIOctpOp.js";var t={id:`sleep-quest`,number:4,name:`Sleep Quest`,icon:`night`,summary:`Set a short wind-down routine, earn progress, and discover space photos when you return.`},n=e=>`
  <a class="launch-card ${e.icon}" href="./${e.id}/">
    <div class="card-top">
      <span class="version-id">V${e.number}</span>
      <span class="version-icon" aria-hidden="true"><i></i></span>
    </div>
    <div class="card-copy">
      <h3>${e.name}</h3>
      <p>${e.summary}</p>
    </div>
    <span class="card-link">Open version <span aria-hidden="true">↗</span></span>
  </a>`;document.querySelector(`#launch-grid`).innerHTML=n(t),e(document.getElementById(`dev-open`));